function setup() {
  createCanvas(400, 400);
}

function draw() {
  background("red");
  let c = color(253,226,226);
  // Head
  noStroke();
  fill(c); 
  circle(200,200,120);
  //R.Ear
  ellipse(260,220,30,60);
  //Shadow
  c = color(215,187,187);
  fill(c);
  arc(200,200,120,120,1.5, PI + QUARTER_PI);
  //L.Ear
  ellipse(140,220,30,60);
  //Piercings
  c = color(0,0,0);
  fill(c);
  circle(137,240,20);
  circle(263,240,20);
  //Beard
  c = color(119,86,86);
  fill(c);
  square(145,230,110,0,0,50,50);
  //Nose_Ring
  stroke('black');
  strokeWeight(10);
  point(200,258);
  noStroke();
  //Nose
  c = color(253,226,226);
  fill(c);
  triangle(190,250,210,250,200,260);
  rect(195,230,10,20);
  //Hair
  c = color(119,86,86);
  fill(c);
  rect(143,125,115,40,40,40,0,0);
  triangle(190,165,210,165,200,170);
  triangle(143,165,160,165,143,230);
  triangle(258,165,240,165,257,230);
  //Glasses
  stroke(255,204,102);
  strokeWeight(4);
  c = color(255,255,255);
  fill(c);
  rect(150,210,40,30,0,0,10,10);
  rect(210,210,40,30,0,0,10,10);
  line(190,210,210,210);
  line(190,220,210,220);
  //Title
  c = (0,0,0);
  noStroke();
  textSize(48);
  fill(c);
  text('Simply Me...',80,100);
  //Signature
  textSize(12);
  text('Zack Leach',300,380);
}